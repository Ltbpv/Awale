# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import joueur as j

class IaAwale(j.Joueur):

    def __init__(self, num, grenier=0):
        """Initialise la classe IA, qui hérite de la classe Joueur."""
        super().__init__("Robot", num, grenier)

    def next_move(self, plateau):
        """Définit le prochain coup à jouer pour l'IA."""
        choix = np.random.randint(1, 6)
        return choix

    def alphaBeta(self, noeud, p, plateau, alpha=-500, beta=500):
        """Détermine le prochain coup, pour une profondeur p, selon l'élagage alpha beta."""
        if self.isFinal(plateau, noeud) or (p == 0):
            return self.evaluation(noeud, plateau)
        else:
            return

    def playables(self, plateau, joueur):
        """Détermine quels sont les prochains coups jouables."""
        moves = []
        for i in range(1, 7):
            if joueur.is_playable(i, plateau):
                moves.append(i)
        return moves

    def evaluation(self, coup, plateau):
        """Donne un score au coup donné en argument, correspondant au nombre de cailloux récupérés."""
        score_simul = self.grenier
        plateau_cpy = plateau[:]
        index = self.simul_distrib(coup, plateau_cpy)
        self.simul_recup(index, plateau_cpy)
        return score_simul - self.grenier

    def isFinal(self, plateau, move):
        """Regarde si le move permet de gagner la partie ou non."""
        score_simul = self.grenier
        plateau_cpy = plateau[:]
        index = self.simul_distrib(move, plateau_cpy)
        self.simul_recup(index, plateau_cpy, score_simul)
        if score_simul >= 25:
            return True

    def simul_distrib(self, choice, plateau_cpy):
        """Simule une distribution de cailloux, et vois si cela affame l'adversaire."""
        i_deb = (self.num - 1) * 6 + (choice - 1)
        nb_cailloux = plateau_cpy[i_deb]
        plateau_cpy[i_deb] = 0
        progression = (-1) ** self.num
        i_current = i_deb
        while nb_cailloux > 0:
            i_current += progression
            if i_current == i_deb:  # Gère le saut du trou de départ pour plus de 12 cailloux
                i_current += progression
            if i_current == 12:
                progression = -1
                i_current = 5
            elif i_current == -1:
                progression = 1
                i_current = 6
            plateau_cpy[i_current] += 1
            nb_cailloux -= 1
        return i_current

    def simul_recup(self, indice, plateau, score_simul):
        """Regarde et récupère les cailloux des trous de fin."""
        if indice <= 5:
            progression = 1
        else:
            progression = -1

        if plateau[indice] not in [2, 3]:
            return

        score_simul += plateau[indice]
        plateau[indice] = 0
        if indice == 6:
            indice = -1
            progression = 1
        elif indice == 5:
            indice = 12
            progression = -1
        self.simul_recup(indice+progression, plateau, score_simul)