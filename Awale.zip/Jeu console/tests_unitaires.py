# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import unittest
import awale as a
import joueur as j


class TestJoueur(unittest.TestCase):
    def test_var(self):
        jou = j.Joueur('zoe', 5)
        self.assertEqual(jou.name, 'zoe')
        self.assertEqual(jou.grenier, 0)
        self.assertEqual(jou.num, 5)

    def test_type(self):
        jou = j.Joueur('zoe', 5)
        jou1 = j.Joueur('leo', 4, 10)
        self.assertIsInstance(jou, j.Joueur)
        self.assertIsInstance(jou1, j.Joueur)


class TestAwale(unittest.TestCase):
    def test_var(self):
        aw = a.Awale()
        aw1 = a.Awale(8)
        self.assertEqual(aw.nbcases, 12)
        self.assertEqual(aw1.nbcases, 8)

    def test_type(self):
        aw = a.Awale()
        aw1 = a.Awale(8)
        self.assertIsInstance(aw, a.Awale)
        self.assertIsInstance(aw1, a.Awale)





