# -*- coding: utf-8 -*-

import joueur as j
import sys
import awale as a
import window as w
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox


def launchAwale():
    """Fonction à appeler pour lancer une partie d'Awalé. @author : phamvale"""
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = w.Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
