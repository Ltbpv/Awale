# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import awale

class Joueur:
    """Définit la classe joueur."""

    def __init__(self, name, numero, grenier=0):
        """Initialise le constructeur de la classe Joueur. @author : phamvale"""
        self.name = name
        self.grenier = grenier
        self.num = numero

    def next_move(self, plateau):
        """Permet au joueur de choisir son prochain coup. @author : phamvale"""
        choice = int(input("De quel trou voulez-vous prélever les cailloux ?"))
        while not (0 < choice < 7 and self.is_playable(choice, plateau) and type(choice) == int):
            print("Veuillez choisir un trou jouable.")
            choice = int(input("De quel trou voulez-vous prélever les cailloux ?"))
        return choice

    def is_playable(self, choice, plateau):
        """Vérifie si le choix du joueur est jouable ou non. @author : phamvale"""
        if plateau[(self.num - 1) * 6 + (choice - 1)] == 0:
            print("Le trou choisi est vide !\n")
            return False
        if not self.nourrir(choice, plateau):
            print("Vous devez nourrir le joueur adverse !\n")
            return False
        return True

    def nourrir(self, choice, plateau):
        """Simule une distribution de cailloux, et vois si cela affame l'adversaire. @author : phamvale"""
        i_deb = (self.num - 1) * 6 + (choice - 1)
        plateau_cpy = plateau[:]
        nb_cailloux = plateau_cpy[i_deb]
        plateau_cpy[i_deb] = 0
        progression = (-1) ** self.num
        i_current = i_deb
        while nb_cailloux > 0:
            i_current += progression
            if i_current == i_deb:  # Gère le saut du trou de départ pour plus de 12 cailloux
                i_current += progression
            if i_current == 12:
                progression = -1
                i_current = 5
            elif i_current == -1:
                progression = 1
                i_current = 6
            plateau_cpy[i_current] += 1
            nb_cailloux -= 1
        if self.num == 1:
            autre_num = 2
        else:
            autre_num = 1
        if plateau_cpy[(autre_num - 1) * 6: autre_num * 6] == [0] * 6:  # Plateau adverse est vide et le reste
            if plateau[(autre_num - 1) * 6: autre_num * 6] == [0] * 6:
                return False
        return True

    def famine(self, plateau, j2, window):
        """Vérifie si il y a un cas de famine, signifiant une fin du jeu. @author : phamvale"""
        for i in range(1, 7):
            if self.nourrir(i, plateau):
                return False
        self.grenier += sum(plateau.cases)
        if plateau.endgame(self, j2):
            plateau.endgame(self, j2)
            return True
        elif self.grenier > j2.grenier:
            plateau.save_scores(self)
            window.messageToPlayer('Fin par famine, victoire de ' + self.name + ' avec un score de ' + str(self.grenier))
            return True
        elif self.grenier < j2.grenier:
            plateau.save_scores(j2)
            window.messageToPlayer('Fin par famine, victoire de ' + j2.name + ' avec un score de ' + str(j2.grenier))
            return True
        else:
            window.messageToPlayer("Égalité des scores avec " + str(self.grenier) + " cailloux chacun !")
            return True