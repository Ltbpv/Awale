from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    """définit une boîte de dialogue pour interagir avec l'utilisateur. @author : phamvale"""

    def setupUi(self, Dialog, main):
        """Paramètre la boîte de dialogue"""
        Dialog.setObjectName("Dialog")
        Dialog.resize(431, 309)
        self.okcancel = QtWidgets.QDialogButtonBox(Dialog)
        self.okcancel.setGeometry(QtCore.QRect(70, 260, 341, 32))
        self.okcancel.setOrientation(QtCore.Qt.Horizontal)
        self.okcancel.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.okcancel.setObjectName("okcancel")

        # Choix du trou
        # Affichage
        self.move = QtWidgets.QLabel(Dialog)
        self.move.setGeometry(QtCore.QRect(20, 80, 91, 21))
        self.move.setObjectName("PlayerMove")

        # Entrée trou
        self.movechoice = QtWidgets.QLineEdit(Dialog)
        self.movechoice.setGeometry(QtCore.QRect(110, 80, 181, 20))
        self.movechoice.setText("")
        self.movechoice.setObjectName("movechoice")

        # ---------
        self.retranslateUi(Dialog)

        self.okcancel.accepted.connect(self.get_info)
        self.okcancel.accepted.connect(Dialog.accept)
        self.okcancel.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        """ définit les titres et textes de la boîte de dialogue"""
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))

        self.move.setText(_translate("Dialog", "Choix"))


    def get_info(self):
        """récupère le choix de l'utilisateur"""
        move = self.movechoice.text()
        self.move = move
        print(self.move)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
