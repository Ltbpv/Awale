from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    """Définit la boîte de dialogue relative à la saisie du nom dans le mode 1 joueur. @author : bourgazo"""
    def setupUi(self, Dialog, main):
        """paramètre la boîte de dialogue"""
        Dialog.setObjectName("Dialog")
        Dialog.resize(431, 309)
        self.okcancel = QtWidgets.QDialogButtonBox(Dialog)
        self.okcancel.setGeometry(QtCore.QRect(70, 260, 341, 32))
        self.okcancel.setOrientation(QtCore.Qt.Horizontal)
        self.okcancel.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.okcancel.setObjectName("okcancel")

        #Joueur 1
        #Affichage
        self.Joueur1 = QtWidgets.QLabel(Dialog)
        self.Joueur1.setGeometry(QtCore.QRect(20, 80, 91, 21))
        self.Joueur1.setObjectName("Joueur1")

        #Entrée du nom
        self.nomjoueur1 = QtWidgets.QLineEdit(Dialog)
        self.nomjoueur1.setGeometry(QtCore.QRect(110, 80, 181, 20))
        self.nomjoueur1.setText("")
        self.nomjoueur1.setObjectName("nomjoueur1")


        #actions des boutons ok et cancel
        self.retranslateUi(Dialog)

        self.okcancel.accepted.connect(self.get_info)
        self.okcancel.accepted.connect(Dialog.accept)
        self.okcancel.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        """ définit le titre et le texte de la boîte de dialogue"""
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))

        self.Joueur1.setText(_translate("Dialog", "Joueur 1"))


    def get_info(self):
        """récupère le nom rentré par l'utilisateur"""
        txt1 = self.nomjoueur1.text()
        self.joueurs = [txt1]
        print(self.joueurs)


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
