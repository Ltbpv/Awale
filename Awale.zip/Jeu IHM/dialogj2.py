# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\thoma\PycharmProjects\pythonProject\InformatiquePython\Projet\ihm\nouvellepartie.ui'
#
# Created by: PyQt5 UI code generator 5.14.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    """Définit la boîte de dialogue relative à la saisie des noms dans le mode 2 joueurs. @author : bourgazo"""
    def setupUi(self, Dialog, main):
        Dialog.setObjectName("Dialog")
        Dialog.resize(431, 309)
        self.okcancel = QtWidgets.QDialogButtonBox(Dialog)
        self.okcancel.setGeometry(QtCore.QRect(70, 260, 341, 32))
        self.okcancel.setOrientation(QtCore.Qt.Horizontal)
        self.okcancel.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.okcancel.setObjectName("okcancel")

        # Joueur 1
        # Affichage
        self.Joueur1 = QtWidgets.QLabel(Dialog)
        self.Joueur1.setGeometry(QtCore.QRect(20, 80, 91, 21))
        self.Joueur1.setObjectName("Joueur1")

        # Entrée nom
        self.nomjoueur1 = QtWidgets.QLineEdit(Dialog)
        self.nomjoueur1.setGeometry(QtCore.QRect(110, 80, 181, 20))
        self.nomjoueur1.setText("")
        self.nomjoueur1.setObjectName("nomjoueur1")

        # Joueur 2
        self.nomjoueur2 = QtWidgets.QLineEdit(Dialog)
        self.nomjoueur2.setGeometry(QtCore.QRect(110, 110, 181, 20))
        self.nomjoueur2.setText("")
        self.nomjoueur2.setObjectName("nomjoueur2")

        self.Joueur2 = QtWidgets.QLabel(Dialog)
        self.Joueur2.setGeometry(QtCore.QRect(20, 110, 91, 21))
        self.Joueur2.setObjectName("Joueur2")

        #actions des boutons ok et cancel
        self.retranslateUi(Dialog)

        self.okcancel.accepted.connect(self.get_info)
        self.okcancel.accepted.connect(Dialog.accept)
        self.okcancel.rejected.connect(Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)


    def retranslateUi(self, Dialog):
        """ définit le titre et le texte de la boîte de dialogue"""
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.Joueur1.setText(_translate("Dialog", "Joueur 1"))
        self.Joueur2.setText(_translate("Dialog", "Joueur 2"))

    def get_info(self):
        """récupère les noms rentrés par les joueurs"""
        txt1, txt2 = self.nomjoueur1.text(), self.nomjoueur2.text()
        self.joueurs = [txt1, txt2]

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
