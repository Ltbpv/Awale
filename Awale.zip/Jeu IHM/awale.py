# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import joueur as j
import json
import sys


class Awale:
    """Définit la classe du jeu Awalé. """

    def __init__(self, nbcases=12):
        """Construit la classe awalé. @author : phamvale"""
        self.nbcases = nbcases
        self.cases = [4] * nbcases

    def __str__(self):
        """Affiche le plateau. @author : phamvale"""
        a = np.array(self.cases)
        a = np.reshape(a, (2, self.nbcases // 2))
        return str(a)

    def distribuer(self, choice, num_joueur):
        """Prends et distribue les graines du trou choisi par le joueur. @author : phamvale"""
        i_deb = (num_joueur - 1) * 6 + (choice - 1)
        nb_cailloux = self.cases[i_deb]
        self.cases[i_deb] = 0
        progression = (-1) ** num_joueur
        i_current = i_deb
        while nb_cailloux > 0:
            i_current += progression
            if i_current == i_deb:  # Gère le saut du trou de départ pour plus de 12 cailloux
                i_current += progression
            if i_current == 12:
                progression = -1
                i_current = 5
            elif i_current == -1:
                progression = 1
                i_current = 6
            self.cases[i_current] += 1
            nb_cailloux -= 1
        return i_current

    def recuperer(self, indice, joueur):
        """Regarde et récupère les cailloux des trous de fin. @author : phamvale"""
        if indice <= 5:
            progression = 1
        else:
            progression = -1

        if self.cases[indice] not in [2, 3]:
            return

        joueur.grenier += self.cases[indice]
        self.cases[indice] = 0
        if indice == 6:
            indice = -1
            progression = 1
        elif indice == 5:
            indice = 12
            progression = -1
        self.recuperer(indice+progression, joueur)

    def save_partie(self, joueur1, joueur2, qui_jouera):
        """Sauvegarde, si souhaité, la partie en cours. @author : bourgazo"""
        # save = input("Voulez-vous sauvegarder la partie ? (oui/non) \n")
        save = 'oui'
        while save not in ['oui', 'non']:
            print("Veuillez choisir oui ou non !")
            save = input("Voulez-vous sauvegarder la partie ? (oui/non) \n")
        if save == 'oui':
            sauv = open('sauvegarde.txt', 'w+')
            sauv.write(str(self.cases) + '/')
            sauv.write(joueur1.name + '; ' + str(joueur1.grenier) + '/' + joueur2.name + '; ' + str(joueur2.grenier))
            sauv.write('/' + str(qui_jouera))
            sauv.close()

    def load_partie(self):
        """Charge la partie sauvegardée, si elle existe. @author : bourgazo"""
        load_game = input("Voulez-vous charger la partie sauvegardée ? (oui/non) \n")
        while load_game not in ['oui', 'non']:
            print("Veuillez choisir oui ou non !")
            load_game = input("Voulez-vous charger la partie sauvegardée ? (oui/non) \n")
        if load_game == 'oui':
            with open('sauvegarde.txt', 'r') as fichier:
                for line in fichier:
                    infos = line.split('/')
                    self.cases = json.loads(infos[0])
                    qui_joue = int(infos[3])
                    joueur1 = infos[1].split('; ')
                    joueur2 = infos[2].split('; ')
            return joueur1, joueur2, qui_joue
        return False

    def save_scores(self, gagnant):
        """Gère le palmarès du jeu, enregistre les scores des gagants. @author : bourgazo"""
        win = open('scores.txt', 'a')
        win.write(gagnant.name + '/' + str(gagnant.grenier) + '\n')
        win.close()

    def endgame(self, j1, j2, window):
        """Définit les conditions d'arrêt et de victoire du jeu. @author : phamvale"""
        if j1.grenier >= 25:
            self.save_scores(j1)
            window.messageToPLayer('Fin du jeu, victoire de ' + j1.name + ' avec un score de' + str(j1.grenier))
            return True
        if j2.grenier >= 25:
            self.save_scores(j2)
            window.messageToPLayer('Fin du jeu, victoire de ' + j2.name + ' avec un score de' + str(j2.grenier))
            return True
        return False

def play():
    """Fonction à appeler pour jouer une partie. @author : phamvale"""
    jeu = Awale()
    reprise = jeu.load_partie()
    if not reprise:
        name1 = input("Pseudo du joueur 1 ?")
        name2 = input("Pseudo du joueur 2 ?")
        j1 = j.Joueur(name1, 1)
        j2 = j.Joueur(name2, 2)
        qui_joue = 1
    else:
        joueur1, joueur2, qui_joue = reprise
        j1 = j.Joueur(joueur1[0], 1, int(joueur1[1]))
        j2 = j.Joueur(joueur2[0], 2, int(joueur2[1]))
    print(jeu)
    while not (jeu.endgame(j1, j2) and j1.famine(jeu, j2) and j2.famine(jeu, j1)):
        if qui_joue == 1:
            print("A " + j1.name + " de jouer !\n")
            print(jeu)
            choice = j1.next_move(jeu.cases)
            dernier_trou = jeu.distribuer(choice, 1)
            print(jeu)
            print("\n")
            ancien_score = j1.grenier
            jeu.recuperer(dernier_trou, j1)
            print("Le joueur 1 a récupéré {} cailloux. \n".format(str(j1.grenier - ancien_score)))
            print(jeu)
            qui_joue = 2
        else:
            print("A " + j2.name + " de jouer !\n")
            print(jeu)
            choice = j2.next_move(jeu.cases)
            dernier_trou = jeu.distribuer(choice, 2)
            print(jeu)
            print("\n")
            ancien_score = j2.grenier
            jeu.recuperer(dernier_trou, j2)
            print("Le joueur 2 a récupéré {} cailloux. \n".format(str(j2.grenier - ancien_score)))
            print(jeu)
            qui_joue = 1
        jeu.save_partie(j1, j2, qui_joue)
    if jeu.endgame(j1, j2):
        jeu.endgame(j1, j2)
    elif j1.famine(jeu, j2):
        j1.famine(jeu, j2)
    else:
        j2.famine(jeu, j1)
